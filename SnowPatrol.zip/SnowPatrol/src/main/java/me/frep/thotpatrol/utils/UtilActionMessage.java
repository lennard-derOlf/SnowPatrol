package me.frep.thotpatrol.utils;

import net.md_5.bungee.api.chat.*;
import net.md_5.bungee.api.chat.hover.content.Text;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Utility for building clickable/hoverable chat messages.
 * Rewritten for 1.13+ using BungeeCord TextComponent API (bundled with Spigot).
 */
public class UtilActionMessage {

    private final List<AMText> textParts = new ArrayList<>();

    public AMText addText(String message) {
        AMText part = new AMText(message);
        textParts.add(part);
        return part;
    }

    public void sendToPlayer(Player player) {
        TextComponent root = new TextComponent();
        for (AMText part : textParts) {
            root.addExtra(part.build());
        }
        player.spigot().sendMessage(root);
    }

    public enum ClickableType {
        RunCommand, SuggestCommand, OpenURL
    }

    public class AMText {
        private final String message;
        private String hoverText = null;
        private ClickableType clickType = null;
        private String clickValue = null;

        public AMText(String message) {
            this.message = message;
        }

        public AMText addHoverText(String... lines) {
            this.hoverText = String.join("\n", lines);
            return this;
        }

        public AMText setClickEvent(ClickableType type, String value) {
            this.clickType = type;
            this.clickValue = value;
            return this;
        }

        TextComponent build() {
            // Parse legacy color codes
            TextComponent component = new TextComponent(
                    TextComponent.fromLegacyText(org.bukkit.ChatColor.translateAlternateColorCodes('&', message))
            );

            if (hoverText != null) {
                component.setHoverEvent(new HoverEvent(
                        HoverEvent.Action.SHOW_TEXT,
                        new Text(TextComponent.fromLegacyText(
                                org.bukkit.ChatColor.translateAlternateColorCodes('&', hoverText)))
                ));
            }

            if (clickType != null && clickValue != null) {
                ClickEvent.Action action;
                switch (clickType) {
                    case RunCommand:
                        action = ClickEvent.Action.RUN_COMMAND;
                        break;
                    case SuggestCommand:
                        action = ClickEvent.Action.SUGGEST_COMMAND;
                        break;
                    case OpenURL:
                        action = ClickEvent.Action.OPEN_URL;
                        break;
                    default:
                        action = ClickEvent.Action.RUN_COMMAND;
                }
                component.setClickEvent(new ClickEvent(action, clickValue));
            }

            return component;
        }
    }
}
