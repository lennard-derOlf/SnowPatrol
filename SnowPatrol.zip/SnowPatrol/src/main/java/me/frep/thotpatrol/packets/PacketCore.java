package me.frep.thotpatrol.packets;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.EnumWrappers;
import me.frep.thotpatrol.ThotPatrol;
import me.frep.thotpatrol.data.DataPlayer;
import me.frep.thotpatrol.packets.events.*;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;

public class PacketCore {

	private static ThotPatrol ThotPatrol;
	private HashSet<EntityType> enabled;
	public static Map<UUID, Integer> movePackets;

	public PacketCore(ThotPatrol ThotPatrol) {
		super();
		PacketCore.ThotPatrol = ThotPatrol;
		enabled = new HashSet<>();
		enabled.add(EntityType.PLAYER);
		movePackets = new HashMap<>();

		// USE_ENTITY - attack detection
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.USE_ENTITY) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final PacketContainer packet = event.getPacket();
				final Player player = event.getPlayer();
				if (player == null) return;

				EnumWrappers.EntityUseAction type;
				try {
					// ProtocolLib 5.x: getEntityUseActions() removed; use getEnumEntityUseActions()
					// which returns the action wrapped in a structure. The action enum is in a sub-struct.
					// Safest cross-version way: read action integer directly.
					// Action: 0=INTERACT, 1=ATTACK, 2=INTERACT_AT
					int actionId = packet.getIntegers().read(1);
					type = actionId == 1 ? EnumWrappers.EntityUseAction.ATTACK : EnumWrappers.EntityUseAction.INTERACT;
				} catch (final Exception ex) {
					try {
						// Fallback for older ProtocolLib 5.x builds that still have this
						type = packet.getEntityUseActions().read(0);
					} catch (Exception ex2) {
						return;
					}
				}

				Bukkit.getServer().getPluginManager().callEvent(new PacketUseEntityEvent(type, player, player));
				if (type == EnumWrappers.EntityUseAction.ATTACK) {
					Bukkit.getServer().getPluginManager()
							.callEvent(new PacketKillAuraEvent(player, PacketPlayerType.USE));
				}
			}
		});

		// POSITION_LOOK (MOVE_PLAYER_POS_ROT in 1.17+)
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.POSITION_LOOK) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				try {
					Bukkit.getServer().getPluginManager().callEvent(new PacketPlayerEvent(player,
							event.getPacket().getDoubles().read(0),
							event.getPacket().getDoubles().read(1),
							event.getPacket().getDoubles().read(2),
							event.getPacket().getFloat().read(0),
							event.getPacket().getFloat().read(1),
							PacketPlayerType.POSLOOK));
				} catch (Exception ignored) {}
			}
		});

		// LOOK (MOVE_PLAYER_ROT in 1.17+)
		ProtocolLibrary.getProtocolManager().addPacketListener(
				new PacketAdapter(PacketCore.ThotPatrol, PacketType.Play.Client.LOOK) {
					@Override
					public void onPacketReceiving(final PacketEvent event) {
						final Player player = event.getPlayer();
						if (player == null) return;
						try {
							Bukkit.getServer().getPluginManager()
									.callEvent(new PacketPlayerEvent(player,
											player.getLocation().getX(),
											player.getLocation().getY(),
											player.getLocation().getZ(),
											event.getPacket().getFloat().read(0),
											event.getPacket().getFloat().read(1),
											PacketPlayerType.POSLOOK));
						} catch (Exception ignored) {}
					}
				});

		// BLOCK_DIG
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.BLOCK_DIG) {
			public void onPacketReceiving(PacketEvent event) {
				PacketContainer packet = event.getPacket();
				Player player = event.getPlayer();
				if (player == null) return;
				try {
					Location blockLocation = new Location(player.getWorld(),
							packet.getBlockPositionModifier().read(0).getX(),
							packet.getBlockPositionModifier().read(0).getY(),
							packet.getBlockPositionModifier().read(0).getZ());
					Bukkit.getServer().getPluginManager().callEvent(new PacketBlockDigEvent(player, blockLocation));
				} catch (Exception ignored) {}
			}
		});

		// POSITION (MOVE_PLAYER_POS in 1.17+)
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.POSITION) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				try {
					Bukkit.getServer().getPluginManager().callEvent(
							new PacketPlayerEvent(player,
									event.getPacket().getDoubles().read(0),
									event.getPacket().getDoubles().read(1),
									event.getPacket().getDoubles().read(2),
									player.getLocation().getYaw(),
									player.getLocation().getPitch(),
									PacketPlayerType.POSITION));
				} catch (Exception ignored) {}
			}
		});

		// BLOCK_PLACE
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.BLOCK_PLACE) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				Bukkit.getServer().getPluginManager().callEvent(new PacketBlockPlaceEvent(event, player));
			}
		});

		// Server POSITION (teleport/correction sent to client) - SYNCHRONIZE_PLAYER_POSITION in 1.21+
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Server.POSITION) {
			@Override
			public void onPacketSending(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				int i = movePackets.getOrDefault(player.getUniqueId(), 0);
				movePackets.put(player.getUniqueId(), i + 1);
			}
		});

		// ENTITY_ACTION
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.ENTITY_ACTION) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final PacketContainer packet = event.getPacket();
				final Player player = event.getPlayer();
				if (player == null) return;
				try {
					// In 1.9+ the action type is at index 1 (entity id at 0)
					Bukkit.getServer().getPluginManager()
							.callEvent(new PacketEntityActionEvent(player, packet.getIntegers().read(1)));
				} catch (Exception ignored) {}
			}
		});

		// ENTITY_VELOCITY - velocity indices in ProtocolLib 5.x: 0=entityId, 1=velX, 2=velY, 3=velZ
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Server.ENTITY_VELOCITY) {
			public void onPacketSending(PacketEvent event) {
				Player player = event.getPlayer();
				PacketContainer packet = event.getPacket();
				if (player == null) return;
				try {
					double x = packet.getIntegers().read(1).doubleValue() / 8000.0;
					double y = packet.getIntegers().read(2).doubleValue() / 8000.0;
					double z = packet.getIntegers().read(3).doubleValue() / 8000.0;
					Vector vec = new Vector(x, y, z);
					Bukkit.getServer().getPluginManager().callEvent(new PacketVelocityEvent(player, vec));
				} catch (Exception ignored) {}
			}
		});

		// KEEP_ALIVE
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.KEEP_ALIVE) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				Bukkit.getServer().getPluginManager().callEvent(new PacketKeepAliveEvent(player));
			}
		});

		// ARM_ANIMATION
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.ARM_ANIMATION) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				Bukkit.getServer().getPluginManager()
						.callEvent(new PacketKillAuraEvent(player, PacketPlayerType.ARM_SWING));
				Bukkit.getServer().getPluginManager().callEvent(new PacketSwingArmEvent(event, player));
			}
		});

		// HELD_ITEM_SLOT
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(PacketCore.ThotPatrol,
				PacketType.Play.Client.HELD_ITEM_SLOT) {
			@Override
			public void onPacketReceiving(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				Bukkit.getServer().getPluginManager().callEvent(new PacketHeldItemChangeEvent(event, player));
			}
		});

		// FLYING (PacketPlayInFlying / MOVE_PLAYER_STATUS_ONLY) is unregistered in
		// ProtocolLib 5.x on 1.17+. Movement is already tracked via POSITION/LOOK/POSITION_LOOK.
	}

	public static void init() {
		movePackets = new HashMap<>();

		// Server POSITION listener for move packet counting
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(
				me.frep.thotpatrol.ThotPatrol.getInstance(), PacketType.Play.Server.POSITION) {
			@Override
			public void onPacketSending(final PacketEvent event) {
				final Player player = event.getPlayer();
				if (player == null) return;
				movePackets.put(player.getUniqueId(), movePackets.getOrDefault(player.getUniqueId(), 0) + 1);
			}
		});

		// USE_ENTITY attack event for reach/killaura checks
		ProtocolLibrary.getProtocolManager().addPacketListener(
				new PacketAdapter(me.frep.thotpatrol.ThotPatrol.getInstance(), PacketType.Play.Client.USE_ENTITY) {
					@Override
					public void onPacketReceiving(PacketEvent event) {
						final PacketContainer packet = event.getPacket();
						final Player player = event.getPlayer();
						if (player == null) return;

						EnumWrappers.EntityUseAction type;
						try {
							int actionId = packet.getIntegers().read(1);
							type = actionId == 1 ? EnumWrappers.EntityUseAction.ATTACK : EnumWrappers.EntityUseAction.INTERACT;
						} catch (Exception ex) {
							try {
								type = packet.getEntityUseActions().read(0);
							} catch (Exception ex2) {
								return;
							}
						}

						if (type != EnumWrappers.EntityUseAction.ATTACK) return;

						try {
							final Entity entity = event.getPacket().getEntityModifier(player.getWorld()).read(0);
							if (entity != null) {
								Bukkit.getServer().getPluginManager().callEvent(
										new PacketAttackEvent(player, entity, PacketPlayerType.USE));
							}
						} catch (Exception ignored) {}
					}
				});

		// LOOK
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(
				me.frep.thotpatrol.ThotPatrol.getInstance(), PacketType.Play.Client.LOOK) {
			@Override
			public void onPacketReceiving(PacketEvent packetEvent) {
				final Player player = packetEvent.getPlayer();
				if (player == null) return;
				try {
					Bukkit.getServer().getPluginManager().callEvent(new PacketPlayerEvent(player,
							player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(),
							packetEvent.getPacket().getFloat().read(0),
							packetEvent.getPacket().getFloat().read(1),
							PacketPlayerType.LOOK));

					final DataPlayer data = me.frep.thotpatrol.ThotPatrol.getInstance().getDataManager().getData(player);
					if (data != null) {
						data.setLastPacket(System.currentTimeMillis());
					}
				} catch (Exception ignored) {}
			}
		});

		// POSITION
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(
				me.frep.thotpatrol.ThotPatrol.getInstance(), PacketType.Play.Client.POSITION) {
			@Override
			public void onPacketReceiving(PacketEvent packetEvent) {
				final Player player = packetEvent.getPlayer();
				if (player == null) return;
				try {
					Bukkit.getServer().getPluginManager().callEvent(new PacketPlayerEvent(player,
							packetEvent.getPacket().getDoubles().read(0),
							packetEvent.getPacket().getDoubles().read(1),
							packetEvent.getPacket().getDoubles().read(2),
							player.getLocation().getYaw(), player.getLocation().getPitch(),
							PacketPlayerType.POSITION));
					final DataPlayer data = me.frep.thotpatrol.ThotPatrol.getInstance().getDataManager().getData(player);
					if (data != null) {
						data.setLastPacket(System.currentTimeMillis());
					}
				} catch (Exception ignored) {}
			}
		});

		// POSITION_LOOK
		ProtocolLibrary.getProtocolManager().addPacketListener(new PacketAdapter(
				me.frep.thotpatrol.ThotPatrol.getInstance(), PacketType.Play.Client.POSITION_LOOK) {
			@Override
			public void onPacketReceiving(PacketEvent packetEvent) {
				final Player player = packetEvent.getPlayer();
				if (player == null) return;
				try {
					Bukkit.getServer().getPluginManager().callEvent(new PacketPlayerEvent(player,
							packetEvent.getPacket().getDoubles().read(0),
							packetEvent.getPacket().getDoubles().read(1),
							packetEvent.getPacket().getDoubles().read(2),
							packetEvent.getPacket().getFloat().read(0),
							packetEvent.getPacket().getFloat().read(1),
							PacketPlayerType.POSLOOK));

					final DataPlayer data = me.frep.thotpatrol.ThotPatrol.getInstance().getDataManager().getData(player);
					if (data != null) {
						data.setLastKillauraPitch(packetEvent.getPacket().getFloat().read(1));
						data.setLastKillauraYaw(packetEvent.getPacket().getFloat().read(0));
						data.setLastPacket(System.currentTimeMillis());
					}
				} catch (Exception ignored) {}
			}
		});

		// FLYING packet removed - unregistered in ProtocolLib 5.x on 1.17+
	}
}
